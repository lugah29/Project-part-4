
exports.getTravelData = (req, res) => {
  res.json({ message: 'Travel survey data' });
};

exports.addTravelSurvey = (req, res) => {
  res.json({ message: 'Travel survey added' });
};
