
exports.getTechnologyData = (req, res) => {
  res.json({ message: 'Technology survey data' });
};

exports.addTechnologySurvey = (req, res) => {
  res.json({ message: 'Technology survey added' });
};
