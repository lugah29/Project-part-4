
exports.getFoodData = (req, res) => {
  res.json({ message: 'Food survey data' });
};

exports.addFoodSurvey = (req, res) => {
  res.json({ message: 'Food survey added' });
};
