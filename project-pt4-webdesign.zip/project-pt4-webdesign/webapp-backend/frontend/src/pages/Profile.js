import React from 'react';

const Profile = () => (
  <div>
    <h2>My Profile</h2>
    {}
  </div>
);

export default Profile;
